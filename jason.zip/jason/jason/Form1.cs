﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace jason
{
    public partial class Form1 : Form
    {
        List<string> playerMU = new List<string>() {"David de Gea", "Victor Lindelof" , "Phil Jones", "Harry Maguire", "Lisandro Martinez",
        "Bruno Fernandez", "Anthony Martial", "Marcus Rashford", "Tyrell Malacia", "Christian Eriksen" , "Casemiro"};
        List<string> nomerMU = new List<string>() { "01", "02", "04", "05", "06", "08", "09", "10", "12", "14", "18" };
        List<string> posisiMU = new List<string>() { "GK", "DF", "DF", "DF", "DF", "MF", "FW", "FW", "DF", "MF", "MF" };

        List<string> playerCH = new List<string>() {"Kepa Arrizabalaga", "Benoit Badiashile", "Enzo Fernandez", "Thiago Silva", "N'Golo Kante",
        "Mateo Kovacic", "Pierre-Emerick Aubameyang", "Christian Pulisic", "Joao Felix", "Ruben Loftus-Cheek", "Raheem Sterling"};
        List<string> nomerCH = new List<string>() { "01", "04", "05", "06", "07", "08", "09", "10", "11", "12", "17" };
        List<string> posisiCH = new List<string>() { "GK", "DF", "MF", "DF", "MF", "MF", "FW", "MF", "FW", "MF", "MF" };

        List<string> playerBM = new List<string>() {"Manuel Neuer", "Dayot Upamecano", "Matthijs de Ligt", "Benjamin Pavart", "Joshua Kimmich",
        "Serge Gnabry", "Leon Goretzka", "Leroy Sane", "Paul Wanner", "Lucas Hernandez", "Thomas Muller"};
        List<string> nomerBM = new List<string>() { "01", "02", "04", "05", "06", "07", "08", "10", "14", "21", "25" };
        List<string> posisiBM = new List<string>() { "GK", "DF", "DF", "DF", "MF", "FW", "MF", "FW", "MF", "DF", "FW" };
        public Form1()
        {
            InitializeComponent();
        }

        public void updateComboCountry()
        {
            CountryComboBox.Items.Clear();
            bool silit = false;
            for(int i = 0; i < TEAMFUTBOL.Count; i++)
            {
                silit = false;
                foreach(string q in CountryComboBox.Items)
                {
                    if(q == TEAMFUTBOL[i].TeamCountry)
                    {
                        silit = true;
                    }
                }
                if(silit == true)
                {

                }
                else
                {
                    CountryComboBox.Items.Add(TEAMFUTBOL[i].TeamCountry);
                }
            }

        }

        public void updateComboTeam()
        {
            TeamComboBox.Items.Clear();
            for(int i = 0;i < TEAMFUTBOL.Count;i++)
            {
                if (TEAMFUTBOL[i].TeamCountry == CountryComboBox.Text)
                {
                    TeamComboBox.Items.Add(TEAMFUTBOL[i].TeamName);
                }
            }
        }

        public void updateListbox()
        {
            listBox1.Items.Clear();
            for(int i = 0; i < TEAMFUTBOL.Count; i++)
            {
                if (TeamComboBox.SelectedItem == TEAMFUTBOL[i].TeamName)
                {
                    foreach(Player d in TEAMFUTBOL[i].PlayerList)
                    {
                        listBox1.Items.Add($"({d.PlayerNumber}) {d.PlayerName.ToString()}, {d.PlayerPos}");
                    }
                }
            }
            
        }
        public List<Team> TEAMFUTBOL = new List<Team>();
        public class Team
        {
            public string TeamName;
            public string TeamCountry;
            public string TeamCity;
            public List<Player> PlayerList = new List<Player>();
        }
        public class Player
        {
            public string PlayerName;
            public string PlayerNumber;
            public string PlayerPos;
        }
        private void label1_Click(object sender, EventArgs e)
        {

        }
        public List<string> Negara = new List<string>();
        private void AddTeam_Click(object sender, EventArgs e)
        {
            bool kembar = false;
            Team timbaru = new Team();
            if (TeamNameTextBox.Text == "" || CountryTeamTextBox.Text == "" || CityTeamTextBox.Text == "")
            {
                MessageBox.Show("You have to fill all the Textbox, Try Again!");
                TeamNameTextBox.Focus();
            }
            else
            {
               for(int i = 0; i < TEAMFUTBOL.Count; i++)
                {
                    if (TEAMFUTBOL[i].TeamName == TeamNameTextBox.Text)
                    {
                        kembar = true;
                    }
                    else
                    {
                        
                    }
                }
                if (kembar == true)
                {
                    MessageBox.Show("Jancok kn stiven, ubahen cok nama tim e asu kontol");
                }
                else
                {
                    Team q = new Team();
                    q.TeamName = TeamNameTextBox.Text;
                    q.TeamCountry = CountryTeamTextBox.Text;
                    TEAMFUTBOL.Add(q);
                }
                
               
            }
            updateComboCountry();
            updateComboTeam();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void AddPlayer_Click(object sender, EventArgs e)
        {
            Player pemain = new Player();
            pemain.PlayerName = PlayerNameTextBox.Text;
            pemain.PlayerPos = PlayerPosTextBox.Text;
            pemain.PlayerNumber = PlayerNumberTextBox.Text;
            for(int i = 0;i < TEAMFUTBOL.Count; i++)
            {
                if (TEAMFUTBOL[i].TeamName == TeamComboBox.SelectedItem)
                {
                    TEAMFUTBOL[i].PlayerList.Add(pemain);
                }
                updateListbox();
            }

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Team kontol = new Team();
            for (int i = 0; i < playerMU.Count; i++)
            {
                Player hihi = new Player();
                hihi.PlayerName = playerMU[i];
                hihi.PlayerNumber = nomerMU[i];
                hihi.PlayerPos = posisiMU[i];
                kontol.PlayerList.Add(hihi);
            }
            kontol.TeamName = "Manchester United";
            kontol.TeamCountry = "England";
            TEAMFUTBOL.Add(kontol);
            kontol = new Team();
            for (int i = 0; i < playerCH.Count; i++)
            {
                Player hihi = new Player();
                hihi.PlayerName = playerCH[i];
                hihi.PlayerNumber = nomerCH[i];
                hihi.PlayerPos = posisiCH[i];
                kontol.PlayerList.Add(hihi);
            }
            kontol.TeamName = "Chelsea";
            kontol.TeamCountry = "England";
            TEAMFUTBOL.Add(kontol);
            kontol = new Team();
            for (int i = 0; i < playerBM.Count; i++)
            {
                Player hihi = new Player();
                hihi.PlayerName = playerBM[i];
                hihi.PlayerNumber = nomerBM[i];
                hihi.PlayerPos = posisiBM[i];
                kontol.PlayerList.Add(hihi);
            }
            kontol.TeamName = "Bayern Munchen";
            kontol.TeamCountry = "Europe";
            TEAMFUTBOL.Add(kontol);
            updateComboCountry();
            updateComboTeam();
        }

        private void CountryComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            updateComboTeam();
        }

        private void TeamComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {

            updateListbox();
        } 

        private void Remove_Click(object sender, EventArgs e)
        {
            for(int i = 0;i < TEAMFUTBOL.Count;i++)
            {
                if (CountryComboBox.SelectedItem == TEAMFUTBOL[i].TeamCountry && TeamComboBox.SelectedItem == TEAMFUTBOL[i].TeamName)
                {
                    for(int j = 0; j < TEAMFUTBOL[i].PlayerList.Count; j++)
                    {
                        if ($"({TEAMFUTBOL[i].PlayerList[j].PlayerNumber}) {TEAMFUTBOL[i].PlayerList[j].PlayerName}, {TEAMFUTBOL[i].PlayerList[j].PlayerPos}" == listBox1.SelectedItem)
                        {
                            TEAMFUTBOL[i].PlayerList.Remove(TEAMFUTBOL[i].PlayerList[j]);
                        }

                    }

                }
            }
            updateListbox();
        }
    }
}

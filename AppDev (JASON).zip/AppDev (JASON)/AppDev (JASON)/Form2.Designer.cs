﻿namespace AppDev__JASON_
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.PinkBUtton = new System.Windows.Forms.RadioButton();
            this.OrangeBUtton = new System.Windows.Forms.RadioButton();
            this.BlackBUtton = new System.Windows.Forms.RadioButton();
            this.label2 = new System.Windows.Forms.Label();
            this.blue = new System.Windows.Forms.RadioButton();
            this.red = new System.Windows.Forms.RadioButton();
            this.WHite = new System.Windows.Forms.RadioButton();
            this.TnC = new System.Windows.Forms.CheckBox();
            this.ContentTrue = new System.Windows.Forms.CheckBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.emot = new System.Windows.Forms.Label();
            this.magic = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(363, 24);
            this.label1.TabIndex = 1;
            this.label1.Text = "Pick your favourite background color :";
            // 
            // PinkBUtton
            // 
            this.PinkBUtton.AutoSize = true;
            this.PinkBUtton.Location = new System.Drawing.Point(3, 18);
            this.PinkBUtton.Name = "PinkBUtton";
            this.PinkBUtton.Size = new System.Drawing.Size(46, 17);
            this.PinkBUtton.TabIndex = 2;
            this.PinkBUtton.TabStop = true;
            this.PinkBUtton.Text = "Pink";
            this.PinkBUtton.UseVisualStyleBackColor = true;
            this.PinkBUtton.CheckedChanged += new System.EventHandler(this.PinkBUtton_CheckedChanged);
            // 
            // OrangeBUtton
            // 
            this.OrangeBUtton.AutoSize = true;
            this.OrangeBUtton.Location = new System.Drawing.Point(144, 18);
            this.OrangeBUtton.Name = "OrangeBUtton";
            this.OrangeBUtton.Size = new System.Drawing.Size(60, 17);
            this.OrangeBUtton.TabIndex = 3;
            this.OrangeBUtton.TabStop = true;
            this.OrangeBUtton.Text = "Orange";
            this.OrangeBUtton.UseVisualStyleBackColor = true;
            // 
            // BlackBUtton
            // 
            this.BlackBUtton.AutoSize = true;
            this.BlackBUtton.Location = new System.Drawing.Point(237, 18);
            this.BlackBUtton.Name = "BlackBUtton";
            this.BlackBUtton.Size = new System.Drawing.Size(52, 17);
            this.BlackBUtton.TabIndex = 4;
            this.BlackBUtton.TabStop = true;
            this.BlackBUtton.Text = "Black";
            this.BlackBUtton.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(12, 80);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(200, 24);
            this.label2.TabIndex = 5;
            this.label2.Text = "Pick your text color :";
            // 
            // blue
            // 
            this.blue.AutoSize = true;
            this.blue.Location = new System.Drawing.Point(134, 116);
            this.blue.Name = "blue";
            this.blue.Size = new System.Drawing.Size(45, 17);
            this.blue.TabIndex = 8;
            this.blue.TabStop = true;
            this.blue.Text = "blue";
            this.blue.UseVisualStyleBackColor = true;
            // 
            // red
            // 
            this.red.AutoSize = true;
            this.red.Location = new System.Drawing.Point(68, 116);
            this.red.Name = "red";
            this.red.Size = new System.Drawing.Size(45, 17);
            this.red.TabIndex = 7;
            this.red.TabStop = true;
            this.red.Text = "Red";
            this.red.UseVisualStyleBackColor = true;
            // 
            // WHite
            // 
            this.WHite.AutoSize = true;
            this.WHite.Location = new System.Drawing.Point(16, 116);
            this.WHite.Name = "WHite";
            this.WHite.Size = new System.Drawing.Size(53, 17);
            this.WHite.TabIndex = 6;
            this.WHite.TabStop = true;
            this.WHite.Text = "White";
            this.WHite.UseVisualStyleBackColor = true;
            // 
            // TnC
            // 
            this.TnC.AutoSize = true;
            this.TnC.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TnC.Location = new System.Drawing.Point(16, 161);
            this.TnC.Name = "TnC";
            this.TnC.Size = new System.Drawing.Size(225, 24);
            this.TnC.TabIndex = 9;
            this.TnC.Text = "i aggre with term n condition";
            this.TnC.UseVisualStyleBackColor = true;
            this.TnC.CheckedChanged += new System.EventHandler(this.AllOfTheCHECK_CheckedChanged);
            // 
            // ContentTrue
            // 
            this.ContentTrue.AutoSize = true;
            this.ContentTrue.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ContentTrue.Location = new System.Drawing.Point(16, 191);
            this.ContentTrue.Name = "ContentTrue";
            this.ContentTrue.Size = new System.Drawing.Size(276, 24);
            this.ContentTrue.TabIndex = 10;
            this.ContentTrue.Text = "All of the content i put above is true";
            this.ContentTrue.UseVisualStyleBackColor = true;
            this.ContentTrue.CheckedChanged += new System.EventHandler(this.ContentTrue_CheckedChanged);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.BlackBUtton);
            this.panel1.Controls.Add(this.OrangeBUtton);
            this.panel1.Controls.Add(this.PinkBUtton);
            this.panel1.Location = new System.Drawing.Point(16, 39);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(292, 38);
            this.panel1.TabIndex = 11;
            // 
            // emot
            // 
            this.emot.AutoSize = true;
            this.emot.Location = new System.Drawing.Point(16, 292);
            this.emot.Name = "emot";
            this.emot.Size = new System.Drawing.Size(214, 13);
            this.emot.TabIndex = 12;
            this.emot.Text = "My Name is __ and my favourite artist is ___";
            this.emot.Click += new System.EventHandler(this.emot_Click);
            // 
            // magic
            // 
            this.magic.Enabled = false;
            this.magic.Location = new System.Drawing.Point(393, 12);
            this.magic.Name = "magic";
            this.magic.Size = new System.Drawing.Size(91, 293);
            this.magic.TabIndex = 13;
            this.magic.Text = "Magic";
            this.magic.UseVisualStyleBackColor = true;
            this.magic.Click += new System.EventHandler(this.magic_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.magic);
            this.Controls.Add(this.emot);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.ContentTrue);
            this.Controls.Add(this.TnC);
            this.Controls.Add(this.blue);
            this.Controls.Add(this.red);
            this.Controls.Add(this.WHite);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form2";
            this.Text = "Form2";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton PinkBUtton;
        private System.Windows.Forms.RadioButton OrangeBUtton;
        private System.Windows.Forms.RadioButton BlackBUtton;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.RadioButton blue;
        private System.Windows.Forms.RadioButton red;
        private System.Windows.Forms.RadioButton WHite;
        private System.Windows.Forms.CheckBox TnC;
        private System.Windows.Forms.CheckBox ContentTrue;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label emot;
        private System.Windows.Forms.Button magic;
    }
}
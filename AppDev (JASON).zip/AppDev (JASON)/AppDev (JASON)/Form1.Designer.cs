﻿namespace AppDev__JASON_
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.NamaTEXT = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.FavArtistTEXT = new System.Windows.Forms.TextBox();
            this.AllOfTheCHECK = new System.Windows.Forms.CheckBox();
            this.SubmitBUTTOn = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(13, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(77, 24);
            this.label1.TabIndex = 0;
            this.label1.Text = "Name :";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // NamaTEXT
            // 
            this.NamaTEXT.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NamaTEXT.Location = new System.Drawing.Point(96, 8);
            this.NamaTEXT.Name = "NamaTEXT";
            this.NamaTEXT.Size = new System.Drawing.Size(365, 29);
            this.NamaTEXT.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(13, 62);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(188, 24);
            this.label2.TabIndex = 2;
            this.label2.Text = "My Favorite Artist : ";
            // 
            // FavArtistTEXT
            // 
            this.FavArtistTEXT.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FavArtistTEXT.Location = new System.Drawing.Point(207, 59);
            this.FavArtistTEXT.Name = "FavArtistTEXT";
            this.FavArtistTEXT.Size = new System.Drawing.Size(254, 29);
            this.FavArtistTEXT.TabIndex = 3;
            // 
            // AllOfTheCHECK
            // 
            this.AllOfTheCHECK.AutoSize = true;
            this.AllOfTheCHECK.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AllOfTheCHECK.Location = new System.Drawing.Point(17, 234);
            this.AllOfTheCHECK.Name = "AllOfTheCHECK";
            this.AllOfTheCHECK.Size = new System.Drawing.Size(276, 24);
            this.AllOfTheCHECK.TabIndex = 4;
            this.AllOfTheCHECK.Text = "All of the content i put above is true";
            this.AllOfTheCHECK.UseVisualStyleBackColor = true;
            this.AllOfTheCHECK.CheckedChanged += new System.EventHandler(this.AllOfTheCHECK_CheckedChanged);
            // 
            // SubmitBUTTOn
            // 
            this.SubmitBUTTOn.Enabled = false;
            this.SubmitBUTTOn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SubmitBUTTOn.Location = new System.Drawing.Point(17, 273);
            this.SubmitBUTTOn.Name = "SubmitBUTTOn";
            this.SubmitBUTTOn.Size = new System.Drawing.Size(91, 34);
            this.SubmitBUTTOn.TabIndex = 5;
            this.SubmitBUTTOn.Text = "Submit";
            this.SubmitBUTTOn.UseVisualStyleBackColor = true;
            this.SubmitBUTTOn.Click += new System.EventHandler(this.SubmitBUTTOn_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(396, 274);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(107, 34);
            this.button1.TabIndex = 6;
            this.button1.Text = "New Page";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.SubmitBUTTOn);
            this.Controls.Add(this.AllOfTheCHECK);
            this.Controls.Add(this.FavArtistTEXT);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.NamaTEXT);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Submit";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox NamaTEXT;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox FavArtistTEXT;
        private System.Windows.Forms.CheckBox AllOfTheCHECK;
        private System.Windows.Forms.Button SubmitBUTTOn;
        private System.Windows.Forms.Button button1;
    }
}


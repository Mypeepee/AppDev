﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppDev__JASON_
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
        int syarat = 0;
        private void PinkBUtton_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void AllOfTheCHECK_CheckedChanged(object sender, EventArgs e)
        {
            if (TnC.Checked == true && ContentTrue.Checked == true)
            {
                magic.Enabled = true;
            }
            else
            {
                magic.Enabled = false;
            }
        }

        private void ContentTrue_CheckedChanged(object sender, EventArgs e)
        {
            if (TnC.Checked == true && ContentTrue.Checked == true)
            {
                magic.Enabled = true;
            }
            else
            {
                magic.Enabled = false;
            }
        }

        private void magic_Click(object sender, EventArgs e)
        {
            //Form1 kintil = new Form1();
            Form1 kintil = Application.OpenForms["Form1"] as Form1;
            if(PinkBUtton.Checked == true)
            {
                kintil.BackColor = Color.Pink;
            }
            else if(OrangeBUtton.Checked == true)
            {
                kintil.BackColor = Color.Orange;
            }
            else if(BlackBUtton.Checked == true)
            {
                kintil.BackColor = Color.Black;
            }

            if(WHite.Checked == true)
            {
                kintil.ForeColor = Color.White;
            }
            else if(red.Checked == true)
            {
                kintil.ForeColor = Color.Red;
            }
            else if(blue.Checked == true)
            {
                kintil.ForeColor = Color.Blue;
            }
        }
        public string emut;
        private string emutt
        {
            get { return emutt; }
            set { emutt = value; }
        }
        private void emot_Click(object sender, EventArgs e)
        {

        }
    }
}

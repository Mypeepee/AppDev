﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppDev__JASON_
{
    public partial class Form1 : Form
    {
        Form2 kontol = new Form2();
        public Form1()
        {
            InitializeComponent();
        }

        
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void AllOfTheCHECK_CheckedChanged(object sender, EventArgs e)
        {
            if (AllOfTheCHECK.Checked = true)
            {
                SubmitBUTTOn.Enabled = true;
            }
            else
            {
                SubmitBUTTOn.Enabled = false;
            }
        }

        private void SubmitBUTTOn_Click(object sender, EventArgs e)
        {
            Form2 kontol = Application.OpenForms["Form2"] as Form2;
            string nama = NamaTEXT.Text;
            string artis = FavArtistTEXT.Text;
            kontol.emut = $"Hi, My name is {nama} and my favorite artist is {artis}";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (NamaTEXT.Text == "" || FavArtistTEXT.Text == "")
            {
                MessageBox.Show("Monyet kau yang periksa, gabole kosoong jembot");
            }
            else
            {
                kontol.Show();
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using SQL;

namespace SQL
{
    public partial class Form1 : Form
    {
        int goblok = 0;
        DataTable dtTeam = new DataTable();
        DataTable dtPlayer = new DataTable();
        DataTable dtPilih = new DataTable();
        DataTable dtKontolYangPeriksa = new DataTable();
        DataTable match = new DataTable();
        DataTable dtTeam1 = new DataTable();
        public Form1()
        {
            InitializeComponent();
        }

        string connectionString = "server = localhost;uid = root;pwd=;database=premier_league";
        string sqlQuery;
        MySqlConnection sqlConnect;
        MySqlCommand sqlCommand;
        MySqlDataAdapter sqlAdapter;
        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            sqlQuery = "select t.team_name, t.team_id From team t;";
            sqlConnect = new MySqlConnection(connectionString);
            sqlCommand = new MySqlCommand(sqlQuery, sqlConnect);
            sqlAdapter = new MySqlDataAdapter(sqlCommand);
            sqlAdapter.Fill(dtTeam);
            
            TeamList.DataSource = dtTeam;
            TeamList.ValueMember = "team_name";
            TeamList.DisplayMember = "team_name";

            sqlQuery = "select t.team_name, t.team_id From team t;";
            sqlConnect = new MySqlConnection(connectionString);
            sqlCommand = new MySqlCommand(sqlQuery, sqlConnect);
            sqlAdapter = new MySqlDataAdapter(sqlCommand);
            sqlAdapter.Fill(dtTeam1);

            comboBox2.DataSource = dtTeam1;
            comboBox2.ValueMember = "team_name";
            comboBox2.DisplayMember = "team_name";
        }

        private void TeamList_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (goblok == 0)
            {
                dtPlayer.Clear();
                dtPilih.Clear();

                sqlQuery = "select p.player_name as nama from player p inner join team t on t.team_id = p.team_id and t.team_name = '" + TeamList.SelectedValue.ToString() + "';";
                sqlConnect = new MySqlConnection(connectionString);
                sqlCommand = new MySqlCommand(sqlQuery, sqlConnect);
                sqlAdapter = new MySqlDataAdapter(sqlCommand);
                sqlAdapter.Fill(dtPilih);

                PlayerList.DataSource = dtPilih;
                PlayerList.ValueMember = "nama";
                PlayerList.DisplayMember = "player_name";
            }

        }

        private void PlayerList_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        private void showMatchDetailToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void playerDataToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void PlayerList_SelectionChangeCommitted(object sender, EventArgs e)
        {

            dtPlayer.Clear();
            dtKontolYangPeriksa.Clear();
            sqlQuery = "select p.player_name as nama, p.team_number as nomor, if(p.playing_pos = 'F','Forward',if(p.playing_pos = 'M','Midfielder',if (p.playing_pos = 'D','Defender','Goalkeeper'))) as posisi, n.nation, t.team_name from player p, team t, nationality n where p.nationality_id = n.nationality_id and t.team_id = p.team_id and p.player_name = '" + PlayerList.SelectedValue.ToString() + "';";
            sqlConnect = new MySqlConnection(connectionString);
            sqlCommand = new MySqlCommand(sqlQuery, sqlConnect);
            sqlAdapter = new MySqlDataAdapter(sqlCommand);
            sqlAdapter.Fill(dtPlayer);


            PlayerName.Text = $"Player Name : {dtPlayer.Rows[0][0].ToString()} ";
            Position.Text = $"Position : {dtPlayer.Rows[0][2].ToString()}";
            PlayingNum.Text = $"Back Number : {dtPlayer.Rows[0][1].ToString()}";
            Nationality.Text = $"Nationality : {dtPlayer.Rows[0][3].ToString()}";
            TeamName.Text = $"Team Name : {dtPlayer.Rows[0][4].ToString()}";


            sqlQuery = "SELECT ifnull(sum(case when d.`type`= 'CY'then 1 else 0 end),0),ifnull(sum(case when d.`type`= 'CR'then 1 else 0 end),0),ifnull(sum(case when d.`type`= 'GO'then 1 else 0 end),0),ifnull(sum(case when d.`type`= 'GW'then 1 else 0 end),0),ifnull(sum(case when d.`type`= 'GP'then 1 else 0 end),0),ifnull(sum(case when d.`type`= 'PM'then 1 else 0 end),0) as KONDISI, p.player_name as nama, p.player_id as kode from player p, dmatch d where d.player_id = p.player_id and p.player_name = '" + PlayerList.SelectedValue.ToString() + "';";
            sqlConnect = new MySqlConnection(connectionString);
            sqlCommand = new MySqlCommand(sqlQuery, sqlConnect);
            sqlAdapter = new MySqlDataAdapter(sqlCommand);
            sqlAdapter.Fill(dtKontolYangPeriksa);

            RedCard.Text = $"Red Card Count = {dtKontolYangPeriksa.Rows[0][1].ToString()}";
            YellowCard.Text = $"Yellow Card Count = {dtKontolYangPeriksa.Rows[0][0].ToString()}";
            GoalScored.Text = $"Goal Scored Count = {dtKontolYangPeriksa.Rows[0][2].ToString()}";
            PenaltyScored.Text = $"Penalty Scored Count = {dtKontolYangPeriksa.Rows[0][4].ToString()}";
            PenaltyMissed.Text = $"Penalty Missed Count = {dtKontolYangPeriksa.Rows[0][5].ToString()}";
            OwnGoal.Text = $"Own Goal Count = {dtKontolYangPeriksa.Rows[0][3].ToString()}";


        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBox2_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            
            sqlQuery = "SELECT d.match_id from dmatch d, `match` m , `match` n WHERE d.match_id = m.match_id AND (m.team_home = d.team_id or m.team_away = d.team_id) AND d.team_id = '" + comboBox2.SelectedValue.ToString() + "' group by d.match_id";
            sqlConnect = new MySqlConnection(connectionString);
            sqlCommand = new MySqlCommand(sqlQuery, sqlConnect);
            sqlAdapter = new MySqlDataAdapter(sqlCommand);
            sqlAdapter.Fill(match);

            comboBox1.DataSource = match;
            comboBox1.ValueMember = "match_id";
            comboBox1.DisplayMember = "match_id";
        }
    }
}

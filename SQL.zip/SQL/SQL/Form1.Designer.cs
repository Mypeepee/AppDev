﻿namespace SQL
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.playerDataToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.showMatchDetailToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panel1 = new System.Windows.Forms.Panel();
            this.OwnGoal = new System.Windows.Forms.Label();
            this.PenaltyMissed = new System.Windows.Forms.Label();
            this.PenaltyScored = new System.Windows.Forms.Label();
            this.GoalScored = new System.Windows.Forms.Label();
            this.RedCard = new System.Windows.Forms.Label();
            this.YellowCard = new System.Windows.Forms.Label();
            this.Nationality = new System.Windows.Forms.Label();
            this.TeamName = new System.Windows.Forms.Label();
            this.PlayingNum = new System.Windows.Forms.Label();
            this.Position = new System.Windows.Forms.Label();
            this.PlayerName = new System.Windows.Forms.Label();
            this.PlayerList = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.TeamList = new System.Windows.Forms.ComboBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.menuStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.playerDataToolStripMenuItem,
            this.showMatchDetailToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1484, 28);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            this.menuStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.menuStrip1_ItemClicked);
            // 
            // playerDataToolStripMenuItem
            // 
            this.playerDataToolStripMenuItem.Name = "playerDataToolStripMenuItem";
            this.playerDataToolStripMenuItem.Size = new System.Drawing.Size(99, 24);
            this.playerDataToolStripMenuItem.Text = "Player Data";
            this.playerDataToolStripMenuItem.Click += new System.EventHandler(this.playerDataToolStripMenuItem_Click);
            // 
            // showMatchDetailToolStripMenuItem
            // 
            this.showMatchDetailToolStripMenuItem.Name = "showMatchDetailToolStripMenuItem";
            this.showMatchDetailToolStripMenuItem.Size = new System.Drawing.Size(148, 24);
            this.showMatchDetailToolStripMenuItem.Text = "Show Match Detail";
            this.showMatchDetailToolStripMenuItem.Click += new System.EventHandler(this.showMatchDetailToolStripMenuItem_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.OwnGoal);
            this.panel1.Controls.Add(this.PenaltyMissed);
            this.panel1.Controls.Add(this.PenaltyScored);
            this.panel1.Controls.Add(this.GoalScored);
            this.panel1.Controls.Add(this.RedCard);
            this.panel1.Controls.Add(this.YellowCard);
            this.panel1.Controls.Add(this.Nationality);
            this.panel1.Controls.Add(this.TeamName);
            this.panel1.Controls.Add(this.PlayingNum);
            this.panel1.Controls.Add(this.Position);
            this.panel1.Controls.Add(this.PlayerName);
            this.panel1.Controls.Add(this.PlayerList);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.TeamList);
            this.panel1.Location = new System.Drawing.Point(13, 32);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(711, 406);
            this.panel1.TabIndex = 1;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // OwnGoal
            // 
            this.OwnGoal.AutoSize = true;
            this.OwnGoal.Location = new System.Drawing.Point(391, 368);
            this.OwnGoal.Name = "OwnGoal";
            this.OwnGoal.Size = new System.Drawing.Size(78, 16);
            this.OwnGoal.TabIndex = 15;
            this.OwnGoal.Text = "Own Goal : -";
            // 
            // PenaltyMissed
            // 
            this.PenaltyMissed.AutoSize = true;
            this.PenaltyMissed.Location = new System.Drawing.Point(391, 341);
            this.PenaltyMissed.Name = "PenaltyMissed";
            this.PenaltyMissed.Size = new System.Drawing.Size(112, 16);
            this.PenaltyMissed.TabIndex = 14;
            this.PenaltyMissed.Text = "Penalty Missed : -";
            // 
            // PenaltyScored
            // 
            this.PenaltyScored.AutoSize = true;
            this.PenaltyScored.Location = new System.Drawing.Point(393, 312);
            this.PenaltyScored.Name = "PenaltyScored";
            this.PenaltyScored.Size = new System.Drawing.Size(112, 16);
            this.PenaltyScored.TabIndex = 13;
            this.PenaltyScored.Text = "Penalty Scored : -";
            // 
            // GoalScored
            // 
            this.GoalScored.AutoSize = true;
            this.GoalScored.Location = new System.Drawing.Point(393, 281);
            this.GoalScored.Name = "GoalScored";
            this.GoalScored.Size = new System.Drawing.Size(96, 16);
            this.GoalScored.TabIndex = 12;
            this.GoalScored.Text = "Goal Scored : -";
            // 
            // RedCard
            // 
            this.RedCard.AutoSize = true;
            this.RedCard.Location = new System.Drawing.Point(393, 208);
            this.RedCard.Name = "RedCard";
            this.RedCard.Size = new System.Drawing.Size(78, 16);
            this.RedCard.TabIndex = 11;
            this.RedCard.Text = "Red Card : -";
            // 
            // YellowCard
            // 
            this.YellowCard.AutoSize = true;
            this.YellowCard.Location = new System.Drawing.Point(393, 244);
            this.YellowCard.Name = "YellowCard";
            this.YellowCard.Size = new System.Drawing.Size(92, 16);
            this.YellowCard.TabIndex = 10;
            this.YellowCard.Text = "Yellow Card : -";
            // 
            // Nationality
            // 
            this.Nationality.AutoSize = true;
            this.Nationality.Location = new System.Drawing.Point(393, 115);
            this.Nationality.Name = "Nationality";
            this.Nationality.Size = new System.Drawing.Size(83, 16);
            this.Nationality.TabIndex = 9;
            this.Nationality.Text = "Nationality : -";
            // 
            // TeamName
            // 
            this.TeamName.AutoSize = true;
            this.TeamName.Location = new System.Drawing.Point(391, 176);
            this.TeamName.Name = "TeamName";
            this.TeamName.Size = new System.Drawing.Size(96, 16);
            this.TeamName.TabIndex = 8;
            this.TeamName.Text = "Team Name : -";
            // 
            // PlayingNum
            // 
            this.PlayingNum.AutoSize = true;
            this.PlayingNum.Location = new System.Drawing.Point(391, 81);
            this.PlayingNum.Name = "PlayingNum";
            this.PlayingNum.Size = new System.Drawing.Size(116, 16);
            this.PlayingNum.TabIndex = 7;
            this.PlayingNum.Text = "Playing Number : -";
            // 
            // Position
            // 
            this.Position.AutoSize = true;
            this.Position.Location = new System.Drawing.Point(391, 46);
            this.Position.Name = "Position";
            this.Position.Size = new System.Drawing.Size(110, 16);
            this.Position.TabIndex = 6;
            this.Position.Text = "Player Position : -";
            // 
            // PlayerName
            // 
            this.PlayerName.AutoSize = true;
            this.PlayerName.Location = new System.Drawing.Point(393, 10);
            this.PlayerName.Name = "PlayerName";
            this.PlayerName.Size = new System.Drawing.Size(99, 16);
            this.PlayerName.TabIndex = 4;
            this.PlayerName.Text = "Player Name : -";
            // 
            // PlayerList
            // 
            this.PlayerList.FormattingEnabled = true;
            this.PlayerList.Location = new System.Drawing.Point(194, 38);
            this.PlayerList.Name = "PlayerList";
            this.PlayerList.Size = new System.Drawing.Size(138, 24);
            this.PlayerList.TabIndex = 3;
            this.PlayerList.SelectedIndexChanged += new System.EventHandler(this.PlayerList_SelectedIndexChanged);
            this.PlayerList.SelectionChangeCommitted += new System.EventHandler(this.PlayerList_SelectionChangeCommitted);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft YaHei UI", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(189, 10);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(149, 25);
            this.label2.TabIndex = 2;
            this.label2.Text = "Choose Player :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft YaHei UI", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(8, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(143, 25);
            this.label1.TabIndex = 1;
            this.label1.Text = "Choose Team :";
            // 
            // TeamList
            // 
            this.TeamList.FormattingEnabled = true;
            this.TeamList.Location = new System.Drawing.Point(13, 38);
            this.TeamList.Name = "TeamList";
            this.TeamList.Size = new System.Drawing.Size(138, 24);
            this.TeamList.TabIndex = 0;
            this.TeamList.SelectedIndexChanged += new System.EventHandler(this.TeamList_SelectedIndexChanged);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.comboBox1);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.comboBox2);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Location = new System.Drawing.Point(744, 32);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(540, 406);
            this.panel2.TabIndex = 2;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(201, 38);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(138, 24);
            this.comboBox1.TabIndex = 19;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft YaHei UI", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(196, 10);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(151, 25);
            this.label3.TabIndex = 18;
            this.label3.Text = "Choose Match :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft YaHei UI", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(15, 10);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(143, 25);
            this.label4.TabIndex = 17;
            this.label4.Text = "Choose Team :";
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(20, 38);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(138, 24);
            this.comboBox2.TabIndex = 16;
            this.comboBox2.SelectedIndexChanged += new System.EventHandler(this.comboBox2_SelectedIndexChanged_1);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1484, 450);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem playerDataToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem showMatchDetailToolStripMenuItem;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox TeamList;
        private System.Windows.Forms.ComboBox PlayerList;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label Position;
        private System.Windows.Forms.Label PlayerName;
        private System.Windows.Forms.Label PenaltyScored;
        private System.Windows.Forms.Label GoalScored;
        private System.Windows.Forms.Label RedCard;
        private System.Windows.Forms.Label YellowCard;
        private System.Windows.Forms.Label Nationality;
        private System.Windows.Forms.Label TeamName;
        private System.Windows.Forms.Label PlayingNum;
        private System.Windows.Forms.Label PenaltyMissed;
        private System.Windows.Forms.Label OwnGoal;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Label label3;
    }
}


﻿namespace bioskop5
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.CancelButton1 = new System.Windows.Forms.Button();
            this.Waktu2 = new System.Windows.Forms.RadioButton();
            this.Waktu3 = new System.Windows.Forms.RadioButton();
            this.Waktu1 = new System.Windows.Forms.RadioButton();
            this.Pesan = new System.Windows.Forms.Button();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.panel2 = new System.Windows.Forms.Panel();
            this.Cancel2 = new System.Windows.Forms.Button();
            this.WaktuPanel22 = new System.Windows.Forms.RadioButton();
            this.WaktuPanel23 = new System.Windows.Forms.RadioButton();
            this.WaktuPanel21 = new System.Windows.Forms.RadioButton();
            this.button4 = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.Cancel3 = new System.Windows.Forms.Button();
            this.WaktuPanel32 = new System.Windows.Forms.RadioButton();
            this.WaktuPanel33 = new System.Windows.Forms.RadioButton();
            this.WaktuPanel31 = new System.Windows.Forms.RadioButton();
            this.button5 = new System.Windows.Forms.Button();
            this.panelkontol = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.pictureBox104 = new System.Windows.Forms.PictureBox();
            this.PKuning = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.Pesanan = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.btnReset = new System.Windows.Forms.Button();
            this.panel5 = new System.Windows.Forms.Panel();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panelkontol.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox104)).BeginInit();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.Control;
            this.pictureBox1.Location = new System.Drawing.Point(13, 13);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(182, 219);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.SystemColors.Control;
            this.pictureBox2.Location = new System.Drawing.Point(278, 13);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(182, 219);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.SystemColors.Control;
            this.pictureBox3.Location = new System.Drawing.Point(531, 13);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(182, 219);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 2;
            this.pictureBox3.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(301, 244);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(133, 18);
            this.label2.TabIndex = 4;
            this.label2.Text = "Uncensored JAV";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(556, 244);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(146, 18);
            this.label3.TabIndex = 5;
            this.label3.Text = "Brazzers Suzzana";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(55, 274);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(81, 37);
            this.button1.TabIndex = 6;
            this.button1.Text = "Beli Tiket";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(331, 274);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(81, 37);
            this.button2.TabIndex = 7;
            this.button2.Text = "Beli Tiket";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(587, 274);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(81, 37);
            this.button3.TabIndex = 8;
            this.button3.Text = "Beli Tiket";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.CancelButton1);
            this.panel1.Controls.Add(this.Waktu2);
            this.panel1.Controls.Add(this.Waktu3);
            this.panel1.Controls.Add(this.Waktu1);
            this.panel1.Controls.Add(this.Pesan);
            this.panel1.Location = new System.Drawing.Point(29, 317);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(131, 248);
            this.panel1.TabIndex = 9;
            // 
            // CancelButton1
            // 
            this.CancelButton1.Location = new System.Drawing.Point(52, 192);
            this.CancelButton1.Name = "CancelButton1";
            this.CancelButton1.Size = new System.Drawing.Size(64, 34);
            this.CancelButton1.TabIndex = 17;
            this.CancelButton1.Text = "Cancel";
            this.CancelButton1.UseVisualStyleBackColor = true;
            this.CancelButton1.Click += new System.EventHandler(this.CancelButton1_Click);
            // 
            // Waktu2
            // 
            this.Waktu2.AutoSize = true;
            this.Waktu2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Waktu2.Location = new System.Drawing.Point(12, 56);
            this.Waktu2.Name = "Waktu2";
            this.Waktu2.Size = new System.Drawing.Size(93, 26);
            this.Waktu2.TabIndex = 16;
            this.Waktu2.TabStop = true;
            this.Waktu2.Text = "10 : 45";
            this.Waktu2.UseVisualStyleBackColor = true;
            // 
            // Waktu3
            // 
            this.Waktu3.AutoSize = true;
            this.Waktu3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Waktu3.Location = new System.Drawing.Point(12, 99);
            this.Waktu3.Name = "Waktu3";
            this.Waktu3.Size = new System.Drawing.Size(93, 26);
            this.Waktu3.TabIndex = 15;
            this.Waktu3.TabStop = true;
            this.Waktu3.Text = "06 : 00";
            this.Waktu3.UseVisualStyleBackColor = true;
            // 
            // Waktu1
            // 
            this.Waktu1.AutoSize = true;
            this.Waktu1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Waktu1.Location = new System.Drawing.Point(12, 14);
            this.Waktu1.Name = "Waktu1";
            this.Waktu1.Size = new System.Drawing.Size(93, 26);
            this.Waktu1.TabIndex = 14;
            this.Waktu1.TabStop = true;
            this.Waktu1.Text = "02 : 45";
            this.Waktu1.UseVisualStyleBackColor = true;
            this.Waktu1.CheckedChanged += new System.EventHandler(this.Waktu1_CheckedChanged);
            // 
            // Pesan
            // 
            this.Pesan.Location = new System.Drawing.Point(12, 145);
            this.Pesan.Name = "Pesan";
            this.Pesan.Size = new System.Drawing.Size(104, 41);
            this.Pesan.TabIndex = 13;
            this.Pesan.Text = "Pesan";
            this.Pesan.UseVisualStyleBackColor = true;
            this.Pesan.Click += new System.EventHandler(this.Pesan_Click_1);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.Cancel2);
            this.panel2.Controls.Add(this.WaktuPanel22);
            this.panel2.Controls.Add(this.WaktuPanel23);
            this.panel2.Controls.Add(this.WaktuPanel21);
            this.panel2.Controls.Add(this.button4);
            this.panel2.Location = new System.Drawing.Point(304, 317);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(131, 248);
            this.panel2.TabIndex = 17;
            // 
            // Cancel2
            // 
            this.Cancel2.Location = new System.Drawing.Point(52, 192);
            this.Cancel2.Name = "Cancel2";
            this.Cancel2.Size = new System.Drawing.Size(64, 34);
            this.Cancel2.TabIndex = 18;
            this.Cancel2.Text = "Cancel";
            this.Cancel2.UseVisualStyleBackColor = true;
            this.Cancel2.Click += new System.EventHandler(this.Cancel2_Click);
            // 
            // WaktuPanel22
            // 
            this.WaktuPanel22.AutoSize = true;
            this.WaktuPanel22.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.WaktuPanel22.Location = new System.Drawing.Point(12, 56);
            this.WaktuPanel22.Name = "WaktuPanel22";
            this.WaktuPanel22.Size = new System.Drawing.Size(93, 26);
            this.WaktuPanel22.TabIndex = 16;
            this.WaktuPanel22.TabStop = true;
            this.WaktuPanel22.Text = "09 : 30";
            this.WaktuPanel22.UseVisualStyleBackColor = true;
            // 
            // WaktuPanel23
            // 
            this.WaktuPanel23.AutoSize = true;
            this.WaktuPanel23.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.WaktuPanel23.Location = new System.Drawing.Point(12, 99);
            this.WaktuPanel23.Name = "WaktuPanel23";
            this.WaktuPanel23.Size = new System.Drawing.Size(93, 26);
            this.WaktuPanel23.TabIndex = 15;
            this.WaktuPanel23.TabStop = true;
            this.WaktuPanel23.Text = "12 : 00";
            this.WaktuPanel23.UseVisualStyleBackColor = true;
            // 
            // WaktuPanel21
            // 
            this.WaktuPanel21.AutoSize = true;
            this.WaktuPanel21.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.WaktuPanel21.Location = new System.Drawing.Point(12, 14);
            this.WaktuPanel21.Name = "WaktuPanel21";
            this.WaktuPanel21.Size = new System.Drawing.Size(93, 26);
            this.WaktuPanel21.TabIndex = 14;
            this.WaktuPanel21.TabStop = true;
            this.WaktuPanel21.Text = "04 : 40";
            this.WaktuPanel21.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(12, 145);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(104, 41);
            this.button4.TabIndex = 13;
            this.button4.Text = "Pesan";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.Cancel3);
            this.panel3.Controls.Add(this.WaktuPanel32);
            this.panel3.Controls.Add(this.WaktuPanel33);
            this.panel3.Controls.Add(this.WaktuPanel31);
            this.panel3.Controls.Add(this.button5);
            this.panel3.Location = new System.Drawing.Point(559, 317);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(131, 248);
            this.panel3.TabIndex = 18;
            // 
            // Cancel3
            // 
            this.Cancel3.Location = new System.Drawing.Point(52, 192);
            this.Cancel3.Name = "Cancel3";
            this.Cancel3.Size = new System.Drawing.Size(64, 34);
            this.Cancel3.TabIndex = 19;
            this.Cancel3.Text = "Cancel";
            this.Cancel3.UseVisualStyleBackColor = true;
            this.Cancel3.Click += new System.EventHandler(this.Cancel3_Click);
            // 
            // WaktuPanel32
            // 
            this.WaktuPanel32.AutoSize = true;
            this.WaktuPanel32.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.WaktuPanel32.Location = new System.Drawing.Point(12, 56);
            this.WaktuPanel32.Name = "WaktuPanel32";
            this.WaktuPanel32.Size = new System.Drawing.Size(93, 26);
            this.WaktuPanel32.TabIndex = 16;
            this.WaktuPanel32.TabStop = true;
            this.WaktuPanel32.Text = "16 : 50";
            this.WaktuPanel32.UseVisualStyleBackColor = true;
            // 
            // WaktuPanel33
            // 
            this.WaktuPanel33.AutoSize = true;
            this.WaktuPanel33.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.WaktuPanel33.Location = new System.Drawing.Point(12, 99);
            this.WaktuPanel33.Name = "WaktuPanel33";
            this.WaktuPanel33.Size = new System.Drawing.Size(93, 26);
            this.WaktuPanel33.TabIndex = 15;
            this.WaktuPanel33.TabStop = true;
            this.WaktuPanel33.Text = "21 : 10";
            this.WaktuPanel33.UseVisualStyleBackColor = true;
            // 
            // WaktuPanel31
            // 
            this.WaktuPanel31.AutoSize = true;
            this.WaktuPanel31.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.WaktuPanel31.Location = new System.Drawing.Point(12, 14);
            this.WaktuPanel31.Name = "WaktuPanel31";
            this.WaktuPanel31.Size = new System.Drawing.Size(93, 26);
            this.WaktuPanel31.TabIndex = 14;
            this.WaktuPanel31.TabStop = true;
            this.WaktuPanel31.Text = "13 : 20";
            this.WaktuPanel31.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(12, 145);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(104, 41);
            this.button5.TabIndex = 13;
            this.button5.Text = "Pesan";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // panelkontol
            // 
            this.panelkontol.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.panelkontol.Controls.Add(this.label4);
            this.panelkontol.Controls.Add(this.pictureBox104);
            this.panelkontol.Location = new System.Drawing.Point(743, 13);
            this.panelkontol.Name = "panelkontol";
            this.panelkontol.Size = new System.Drawing.Size(577, 552);
            this.panelkontol.TabIndex = 19;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.SystemColors.HotTrack;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(257, 505);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(82, 25);
            this.label4.TabIndex = 101;
            this.label4.Text = "LAYAR";
            // 
            // pictureBox104
            // 
            this.pictureBox104.BackColor = System.Drawing.SystemColors.Highlight;
            this.pictureBox104.Location = new System.Drawing.Point(84, 489);
            this.pictureBox104.Name = "pictureBox104";
            this.pictureBox104.Size = new System.Drawing.Size(427, 56);
            this.pictureBox104.TabIndex = 100;
            this.pictureBox104.TabStop = false;
            // 
            // PKuning
            // 
            this.PKuning.Location = new System.Drawing.Point(1345, 12);
            this.PKuning.Name = "PKuning";
            this.PKuning.Size = new System.Drawing.Size(136, 34);
            this.PKuning.TabIndex = 20;
            this.PKuning.Text = "Reserve";
            this.PKuning.UseVisualStyleBackColor = true;
            this.PKuning.Click += new System.EventHandler(this.PKuning_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 244);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(193, 18);
            this.label1.TabIndex = 21;
            this.label1.Text = "Mario Party Orgy Edition";
            // 
            // Pesanan
            // 
            this.Pesanan.AutoSize = true;
            this.Pesanan.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Pesanan.Location = new System.Drawing.Point(1345, 82);
            this.Pesanan.Name = "Pesanan";
            this.Pesanan.Size = new System.Drawing.Size(167, 25);
            this.Pesanan.TabIndex = 22;
            this.Pesanan.Text = "Pesanan Anda :";
            // 
            // panel4
            // 
            this.panel4.Location = new System.Drawing.Point(1350, 110);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(187, 448);
            this.panel4.TabIndex = 24;
            // 
            // btnReset
            // 
            this.btnReset.Location = new System.Drawing.Point(1345, 52);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(75, 23);
            this.btnReset.TabIndex = 25;
            this.btnReset.Text = "Reset";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click_1);
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.pictureBox4);
            this.panel5.Location = new System.Drawing.Point(29, 581);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(1508, 128);
            this.panel5.TabIndex = 27;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Location = new System.Drawing.Point(11, 13);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(105, 106);
            this.pictureBox4.TabIndex = 0;
            this.pictureBox4.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1549, 712);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.Pesanan);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.PKuning);
            this.Controls.Add(this.panelkontol);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panelkontol.ResumeLayout(false);
            this.panelkontol.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox104)).EndInit();
            this.panel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.RadioButton Waktu2;
        private System.Windows.Forms.RadioButton Waktu3;
        private System.Windows.Forms.RadioButton Waktu1;
        private System.Windows.Forms.Button Pesan;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.RadioButton WaktuPanel22;
        private System.Windows.Forms.RadioButton WaktuPanel23;
        private System.Windows.Forms.RadioButton WaktuPanel21;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.RadioButton WaktuPanel32;
        private System.Windows.Forms.RadioButton WaktuPanel33;
        private System.Windows.Forms.RadioButton WaktuPanel31;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Panel panelkontol;
        private System.Windows.Forms.Button CancelButton1;
        private System.Windows.Forms.Button Cancel2;
        private System.Windows.Forms.Button Cancel3;
        private System.Windows.Forms.PictureBox pictureBox104;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button PKuning;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label Pesanan;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.PictureBox pictureBox4;
    }
}


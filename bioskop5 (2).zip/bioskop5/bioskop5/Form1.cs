﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace bioskop5
{
    public partial class Form1 : Form
    {

        

        private string waktu;
        List<Button> selectedButtons = new List<Button>();
        List<string> PesananDisimpan = new List<string>();
        public Form1()
        {
            InitializeComponent();
            panel1.Visible = false;
            panel2.Visible = false;
            panel3.Visible = false;
            panelkontol.Visible = false;
            Pesanan.Visible = false;
            PKuning.Visible = false;
            btnReset.Visible = false;
        }
        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
        private Button lastClickedButton; // variabel untuk menyimpan button yang terakhir ditekan



        public int kuningseat = 0;
        public PictureBox pictureBox = new PictureBox();
        private void SetPictureBoxColors()
        {
            
            Button[,] buttons = new Button[10, 10];
            Random random = new Random();
            for (int i = 0; i < 10; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    buttons[i, j] = new Button();
                    buttons[i, j].Location = new Point(i * 45, j * 40);
                    buttons[i, j].Size = new Size(25, 25);

                    int randomValue = random.Next(1, 5);
                    if (randomValue == 1)
                    {
                        buttons[i, j].BackColor = Color.Crimson;
                    }
                    else
                    {
                        buttons[i, j].BackColor = Color.Chartreuse;
                    }

                    buttons[i, j].Click += new EventHandler(pictureBox_Click);

                    panelkontol.Controls.Add(buttons[i, j]);
                }
            }
        }
        private void pictureBox_Click(object sender, EventArgs e)
        {
            Button clickedButton = (Button)sender;
            if (clickedButton.BackColor == Color.Chartreuse)
            {
                selectedButtons.Add(clickedButton);
                clickedButton.BackColor = Color.Yellow;
                kuningseat += 1;
                selectedButtons.Add(clickedButton);
            }
            else if (clickedButton.BackColor == Color.Crimson)
            {
                MessageBox.Show("Sudah direservasi");
            }
        }
        private void butonkuningmenjadihijau()
        {
            foreach (Button btn in panelkontol.Controls.OfType<Button>())
            {
                if (btn.BackColor == Color.Yellow)
                {
                    btn.BackColor = Color.Crimson;
                }
            }
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            /// oi yang meriksa, ini ak harusnya dah dapet bonus ya!. makasi
            /// note kalau gabisa di run, hapus aja dari line 102 - 132. mmg pantek
            string file = "konyol.txt";
            string[] lines = File.ReadAllLines(file);
            List<string>perantara = new List<string>();
            foreach(string line in lines)
            {
                perantara.AddRange(line.Split(','));
            }
            List<string> titles = new List<string>();
            List<string> moviePosters = new List<string>();
            foreach (string baris in perantara)
            {
                if (baris[0] == 'C')
                {
                    moviePosters.Add(baris);
                }
                else
                {
                    titles.Add(baris);
                }
            }
            int wewe = 0;
            Label lbl = new Label();
            for(int i = 0; i < titles.Capacity; i++)
            {
                lbl.Text = $"{titles[i]}";
                lbl.Location = new Point(10 + wewe * 45, 10);
                lbl.AutoSize = true;
                panel5.Controls.Add(lbl);
            }
            
            wewe++;

            string imageUrl = "https://nintendoeverything.com/wp-content/uploads/The-Super-Mario-Bros.-Movie-poster.jpg";
            WebClient webClient = new WebClient();
            byte[] imageBytes = webClient.DownloadData(imageUrl);
            using (var ms = new System.IO.MemoryStream(imageBytes))
            {
                Image image = Image.FromStream(ms);
                pictureBox1.Image = image;
            }
            string imageUrl2 = "https://pbs.twimg.com/media/E8i9tLXUUAAqS0T?format=jpg&name=4096x4096";
            WebClient webClient2 = new WebClient();
            byte[] imageBytes2 = webClient.DownloadData(imageUrl2);
            using (var ms = new System.IO.MemoryStream(imageBytes2))
            {
                Image image = Image.FromStream(ms);
                pictureBox2.Image = image;
            }

            string imageUrl3 = "https://cdn.tmpo.co/data/2018/09/23/id_735800/735800_720.jpg";
            WebClient webClient3 = new WebClient();
            byte[] imageBytes3 = webClient.DownloadData(imageUrl3);
            using (var ms = new System.IO.MemoryStream(imageBytes3))
            {
                Image image = Image.FromStream(ms);
                pictureBox3.Image = image;
            }

            string imageUrl4 = "https://nintendoeverything.com/wp-content/uploads/The-Super-Mario-Bros.-Movie-poster.jpg";
            WebClient webClient4 = new WebClient();
            byte[] imageBytes4 = webClient.DownloadData(imageUrl4);
            using (var ms = new System.IO.MemoryStream(imageBytes4))
            {
                Image image = Image.FromStream(ms);
                pictureBox4.Image = image;
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
        public string judul;
        private void button1_Click(object sender, EventArgs e)
        {
            judul += "Mario Party Orgy Edition";
            panel1.Visible = true;
            panel2.Visible = false; panel3.Visible = false;panelkontol.Visible = false;
            PKuning.Visible = false;
            btnReset.Visible = false;
        }

        private void CancelButton1_Click(object sender, EventArgs e)
        {
            panel1.Visible = false;
        }

        private void Pesan_Click(object sender, EventArgs e)
        {
            
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            judul += "Uncensored JAV";
            panelkontol.Controls.Clear();
            panel2.Visible = true;
            panel1.Visible=false;panel3.Visible = false;panelkontol.Visible=false;
            PKuning.Visible = false;
            btnReset.Visible = false;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (WaktuPanel21.Checked == false && WaktuPanel22.Checked == false && WaktuPanel23.Checked == false)
            {

            }
            else if (WaktuPanel21.Checked == true)
            {
                waktu += "04 : 40";
                PKuning.Visible = true;
                btnReset.Visible = true;
                panelkontol.Visible = true;
                SetPictureBoxColors();
                pictureBox.Click += new EventHandler(pictureBox_Click);
                panelkontol.Controls.Add(pictureBox);


            }
            else if (WaktuPanel22.Checked == true)
            {
                waktu += "09 : 30";
                PKuning.Visible = true;
                btnReset.Visible = true;
                Pesanan.Visible = true;
                panelkontol.Visible = true;
                SetPictureBoxColors();
                pictureBox.Click += new EventHandler(pictureBox_Click); 
                panelkontol.Controls.Add(pictureBox);
            }
            else if (WaktuPanel23.Checked == true)
            {
                waktu += "12 : 00";
                Pesanan.Visible = true;
                PKuning.Visible = true;
                btnReset.Visible = true;
                panelkontol.Visible = true;
                SetPictureBoxColors();
                pictureBox.Click += new EventHandler(pictureBox_Click); 
                panelkontol.Controls.Add(pictureBox);


            }
        }

        private void Cancel2_Click(object sender, EventArgs e)
        {
            panel2.Visible = false;
        }

        private void Cancel3_Click(object sender, EventArgs e)
        {
            panel3.Visible = false;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (WaktuPanel31.Checked == false && WaktuPanel32.Checked == false && WaktuPanel33.Checked == false)
            {

            }
            else if (WaktuPanel31.Checked == true)
            {
                waktu += "13 : 20";
                PKuning.Visible = true;
                btnReset.Visible = true;
                panelkontol.Visible = true;
                SetPictureBoxColors();
                pictureBox.Click += new EventHandler(pictureBox_Click);
                panelkontol.Controls.Add(pictureBox);


            }
            else if (WaktuPanel32.Checked == true)
            {
                waktu += "16 : 50";
                PKuning.Visible = true;
                btnReset.Visible = true;
                Pesanan.Visible = true;
                panelkontol.Visible = true;
                SetPictureBoxColors();
                pictureBox.Click += new EventHandler(pictureBox_Click); 
                panelkontol.Controls.Add(pictureBox);
            }
            else if (WaktuPanel33.Checked == true)
            {
                waktu += "21 : 10";
                Pesanan.Visible = true;
                PKuning.Visible = true;
                btnReset.Visible = true;
                panelkontol.Visible = true;
                SetPictureBoxColors();
                pictureBox.Click += new EventHandler(pictureBox_Click);
                panelkontol.Controls.Add(pictureBox);


            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            judul += "Brazzers Suzzana";
            panelkontol.Controls.Clear();
            panel3.Visible = true;
            panelkontol.Visible = false;
            panel1.Visible = false;
            panel2.Visible = false;
        }

        private void Pesan_Click_1(object sender, EventArgs e)
        {
            if (Waktu1.Checked == false && Waktu2.Checked == false && Waktu3.Checked == false)
            {

            }
            else if (Waktu1.Checked == true)
            {
                waktu +="02 : 45";
                PKuning.Visible = true;
                btnReset.Visible = true;
                panelkontol.Visible = true;
                SetPictureBoxColors();
                pictureBox.Click += new EventHandler(pictureBox_Click); 
                panelkontol.Controls.Add(pictureBox);


            }
            else if (Waktu2.Checked == true)
            {
                waktu += "10 : 45";
                PKuning.Visible = true;
                btnReset.Visible = true;
                Pesanan.Visible = true;
                panelkontol.Visible = true;
                SetPictureBoxColors();
                pictureBox.Click += new EventHandler(pictureBox_Click);
                panelkontol.Controls.Add(pictureBox);
            }
            else if (Waktu3.Checked == true)
            {
                waktu += "06 : 00";
                Pesanan.Visible = true;
                PKuning.Visible = true;
                btnReset.Visible = true;
                panelkontol.Visible = true;
                SetPictureBoxColors();
                pictureBox.Click += new EventHandler(pictureBox_Click); 
                panelkontol.Controls.Add(pictureBox);


            }
        }
        private int labelCount = 0;
        private void PKuning_Click(object sender, EventArgs e)
        {
            int selectedCount = selectedButtons.Count;
            if (selectedCount == 0)
            {
                MessageBox.Show("Anda belum memilih kursi");
            }
            else
            {
                butonkuningmenjadihijau();
                Label lbl = new Label();
                lbl.Text = $"{judul.ToString()}\nJumlah Seat : {kuningseat}\nPada Jam : {waktu}";
                lbl.Location = new Point(10, 10 + labelCount * 45);
                lbl.AutoSize = true;
                panel4.Controls.Add(lbl);
                labelCount++;
                selectedButtons.Clear();
                btnReset.Visible = false;
                PKuning.Visible = false;
                judul = "";
                kuningseat = 0;
                waktu = "";
                panel1.Visible = false;
                panel2.Visible = false;
                panel3.Visible = false;
            }
        }

        private void btnReset_Click_1(object sender, EventArgs e)
        {
            foreach (Button button in selectedButtons)
            {
                button.BackColor = Color.Chartreuse;
            }
            selectedButtons.Clear();
            kuningseat = 0;
        }

        private void Waktu1_CheckedChanged(object sender, EventArgs e)
        {

        }
        
    }
}
    
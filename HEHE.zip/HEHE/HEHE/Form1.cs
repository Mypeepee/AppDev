﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace HEHE
{
    public partial class Form1 : Form
    {
        private DataTable dtSimpan;
        public void ngitung()
        {

        }
        public string IDCategory = "";
        public string IDProduct = "";
        DataTable dtProduct = new DataTable();
        DataTable dtCategory = new DataTable();

        public Form1()
        {
            InitializeComponent();

        }

        private void addproductpakecategorybeda()
        {

        }
        private void Form1_Load(object sender, EventArgs e)
        { 
            ///
            dtProduct.Columns.Add("ID Product");
            dtProduct.Columns.Add("Nama Product");
            dtProduct.Columns.Add("Harga");
            dtProduct.Columns.Add("Stok");
            dtProduct.Columns.Add("ID Category");
            dtProduct.Rows.Add("J001", "Jas Hitam", "100000", 10, "C1");
            dtProduct.Rows.Add("T001", "T-Shirt BlackPink", "70000", 20, "C2");
            dtProduct.Rows.Add("T002", "T-Shirt Obsesivve", "75000", 16, "C2");
            dtProduct.Rows.Add("R001", "Rok Mini", "82000", 6, "C3");
            dtProduct.Rows.Add("J001", "Jeans Biru", "90000", 5, "C4");
            dtProduct.Rows.Add("C001", "Celana Pendek Coklat", "60000", 11, "C4");
            dtProduct.Rows.Add("C002", "Cawat Blink-Blink", "1000000", 1, "C5");
            dtProduct.Rows.Add("R002", "Rocca Shirt", "50000", 8, "C2");
            dataGridView1.DataSource = dtProduct;
            dtCategory.Columns.Add("ID Category");
            dtCategory.Columns.Add("Nama Category");
            dtCategory.Rows.Add("C1", "Jas");
            dtCategory.Rows.Add("C2", "T-Shirt");
            dtCategory.Rows.Add("C3", "Rok");
            dtCategory.Rows.Add("C4", "Celana");
            dtCategory.Rows.Add("C5", "Sempak");
            DatagridviewCategory.DataSource = dtCategory;
            ComboBoxCategory.Items.Add("Jas");
            ComboBoxCategory.Items.Add("T-Shirt");
            ComboBoxCategory.Items.Add("Rok");
            ComboBoxCategory.Items.Add("Celana");
            ComboBoxCategory.Items.Add("Sempak");
            ComboBoxFilter.Items.Add("Jas");
            ComboBoxFilter.Items.Add("T-Shirt");
            ComboBoxFilter.Items.Add("Rok");
            ComboBoxFilter.Items.Add("Celana");
            ComboBoxFilter.Items.Add("Sempak");
            dtSimpan = (DataTable)dataGridView1.DataSource;
            ///
        }
        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void AddProductButton_Click(object sender, EventArgs e)
        {
            if(NamaDetailsTextBox.Text == "" || ComboBoxCategory.SelectedItem == null || HargaTextBox.Text == "" || StockTextBox.Text == null)
            {
                MessageBox.Show("Fill all the blank pages you dumbfuck!");
            }
            else
            {
                int result;
                if(!int.TryParse(StockTextBox.Text, out result) || !int.TryParse(HargaTextBox.Text, out result))
                {
                    StockTextBox.Text = "";
                    HargaTextBox.Text = "";
                    MessageBox.Show("Please Input Int you fat whale!");
                }
                else
                {
                    
                    if(ComboBoxCategory.SelectedItem == "Jas")
                    {
                        IDCategory = "C1";
                        IDProduct = "J";
                    }
                    else if(ComboBoxCategory.SelectedItem == "T-Shirt")
                    {
                        IDCategory = "C2";
                        IDProduct = "T";
                    }
                    else if(ComboBoxCategory.SelectedItem == "Rok")
                    {
                        IDCategory = "C3";
                        IDProduct = "R";
                    }
                    else if(ComboBoxCategory.SelectedItem == "Celana")
                    {
                        IDCategory = "C4";
                        IDProduct = "C";
                    }
                    else if (ComboBoxCategory.SelectedItem == "Sempak")
                    {
                        IDCategory = "C5";
                        IDProduct = "S";
                    }
                    else
                    {
                        string hurufpertamaCategory = NamaDetailsTextBox.Text.Substring(0, 1);
                        string dapatvalue = ComboBoxCategory.SelectedItem.ToString();
                        int rowIndex = -1;
                        foreach (DataGridViewRow rowe in DatagridviewCategory.Rows)
                        {
                            if (rowe.Cells[1].Value.ToString().Equals(dapatvalue))
                            {
                                rowIndex = rowe.Index;
                                break;
                            }
                        }

                        if (rowIndex != -1)
                        {
                            IDCategory = DatagridviewCategory.Rows[rowIndex].Cells[0].Value.ToString();
                        }
                        IDProduct = hurufpertamaCategory;
                        
                    }

                    ////
                    ///
                    dtProduct.Rows.Add(IDProduct, NamaDetailsTextBox.Text, HargaTextBox.Text, StockTextBox.Text, IDCategory.ToString());
                }
            }
        }

        private void AddCategoryButton_Click(object sender, EventArgs e)
        {
            int IDCategoryCount = dtCategory.Rows.Count;
            if(CategoryNamaTextBox.Text == "")
            {
                MessageBox.Show("You arent filling the blank space you dirty cows!");
            }
            else
            {
                bool kembar = false;
                foreach (DataGridViewRow row in DatagridviewCategory.Rows)
                {
                    foreach (DataGridViewCell cell in row.Cells)
                    {
                        if (cell.Value != null && cell.Value.ToString() == CategoryNamaTextBox.Text)
                        {
                            kembar = true;
                            break;
                        }
                    }
                    if (kembar) break;
                }

                if (kembar)
                {
                    MessageBox.Show("Are You stupid you dummy fox?, change the value!.");
                    CategoryNamaTextBox.Focus();
                }
                else
                {
                    IDCategoryCount += 1;
                    dtCategory.Rows.Add($"C{IDCategoryCount}", CategoryNamaTextBox.Text);
                    ComboBoxCategory.Items.Add(CategoryNamaTextBox.Text);
                    ComboBoxFilter.Items.Add(CategoryNamaTextBox.Text);
                }

            }
        }

        private void RemoveCategoryButton_Click(object sender, EventArgs e)
        {
            DataGridViewSelectedRowCollection selectedRows = dataGridView1.SelectedRows;
            int rowIndex = DatagridviewCategory.CurrentRow.Index;
            foreach (DataGridViewCell cell in DatagridviewCategory.SelectedCells)
            {
                dtCategory.Rows.RemoveAt(cell.RowIndex);
                if(selectedRows.Count > 0)
                {
                    rowIndex = DatagridviewCategory.Rows.IndexOf(selectedRows[-1]); 
                }   
            }
            ComboBoxCategory.Items.RemoveAt(rowIndex);
            ComboBoxFilter.Items.RemoveAt(rowIndex);
        }

        private void ComboBoxCategory_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void ComboBoxFilter_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(ComboBoxFilter.SelectedItem == "Jas")
            {
                dataGridView1.DataSource = dtSimpan;
                DataTable dt = ((DataTable)dataGridView1.DataSource).Clone();
                foreach (DataRow dr in ((DataTable)dataGridView1.DataSource).Rows)
                {
                    if (dr["ID Category"].ToString() == "C1")
                    {
                        dt.ImportRow(dr);
                    }
                }

                dataGridView1.DataSource = dt;
            }
            else if (ComboBoxFilter.SelectedItem == "T-Shirt")
            {
                dataGridView1.DataSource = dtSimpan;
                DataTable dt = ((DataTable)dataGridView1.DataSource).Clone();
                foreach (DataRow dr in ((DataTable)dataGridView1.DataSource).Rows)
                {
                    if (dr["ID Category"].ToString() == "C2")
                    {
                        dt.ImportRow(dr);
                    }
                }

                dataGridView1.DataSource = dt;
            }
            else if (ComboBoxFilter.SelectedItem == "Rok")
            {
                dataGridView1.DataSource = dtSimpan;
                DataTable dt = ((DataTable)dataGridView1.DataSource).Clone();
                foreach (DataRow dr in ((DataTable)dataGridView1.DataSource).Rows)
                {
                    if (dr["ID Category"].ToString() == "C3")
                    {
                        dt.ImportRow(dr);
                    }
                }

                dataGridView1.DataSource = dt;
            }
            else if (ComboBoxFilter.SelectedItem == "Celana")
            {
                dataGridView1.DataSource = dtSimpan;
                DataTable dt = ((DataTable)dataGridView1.DataSource).Clone();
                foreach (DataRow dr in ((DataTable)dataGridView1.DataSource).Rows)
                {
                    if (dr["ID Category"].ToString() == "C4")
                    {
                        dt.ImportRow(dr);
                    }
                }

                dataGridView1.DataSource = dt;
            }
            else if (ComboBoxFilter.SelectedItem == "Sempak")
            {
                dataGridView1.DataSource = dtSimpan;
                DataTable dt = ((DataTable)dataGridView1.DataSource).Clone();
                foreach (DataRow dr in ((DataTable)dataGridView1.DataSource).Rows)
                {
                    if (dr["ID Category"].ToString() == "C5")
                    {
                        dt.ImportRow(dr);
                    }
                }

                dataGridView1.DataSource = dt;
            }
            else
            {
                        string dapatvalue = ComboBoxCategory.SelectedItem.ToString();
                        int rowIndex = -1;
                string kontolkuingindiemutparaceweceweisbhahahacmonla = "";
                        foreach (DataGridViewRow rowe in DatagridviewCategory.Rows)
                        {
                            if (rowe.Cells[1].Value.ToString().Equals(dapatvalue))
                            {
                                rowIndex = rowe.Index;
                                break;
                            }
                        }

                        if (rowIndex != -1)
                        {
                            kontolkuingindiemutparaceweceweisbhahahacmonla = DatagridviewCategory.Rows[rowIndex].Cells[0].Value.ToString();
                        }


                //KONTOLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLL


                dataGridView1.DataSource = dtSimpan;
                DataTable dt = ((DataTable)dataGridView1.DataSource).Clone();
                foreach (DataRow dr in ((DataTable)dataGridView1.DataSource).Rows)
                {
                    if (dr["ID Category"].ToString() == kontolkuingindiemutparaceweceweisbhahahacmonla) // c5 lah yang harus kita samakan dengan yang di datagridview1
                    {
                        dt.ImportRow(dr);
                    }
                }

                dataGridView1.DataSource = dt;
            }
        }

        private void FilterButton_Click(object sender, EventArgs e)
        {
            ComboBoxFilter.Enabled = true;
            ComboBoxFilter.Visible = true;
        }

        private void AllButton_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = dtSimpan;
        }

        private void RemoveProductButton_Click(object sender, EventArgs e)
        {
            DataGridViewSelectedRowCollection selectedRows = dataGridView1.SelectedRows;
            int rowIndex = dataGridView1.CurrentRow.Index;
            foreach (DataGridViewCell cell in dataGridView1.SelectedCells)
            {
                dataGridView1.Rows.RemoveAt(cell.RowIndex);

            }
        }

        private void EditProductButton_Click(object sender, EventArgs e)
        {
            string namaProduk;
            string hargaProduk;
            string stokProduk;
            if (dataGridView1.SelectedRows.Count > 0) // Pastikan ada baris yang dipilih pada DataGridView
            {
                MessageBox.Show("Select the row first you dumb, dont make mess with me");
            }
            else
            {
                for(int i = 0; i < dataGridView1.Rows.Count; i++)
                {
                    if(i != -1)
                    {
                        DataGridViewRow row = dataGridView1.SelectedRows[i];
                        DataGridViewSelectedRowCollection selectedRows = dataGridView1.SelectedRows;
                        int rowIndex = dataGridView1.CurrentRow.Index;
                        // Mengambil nilai dari kolom "namaproduk" dan "harga produk" pada baris yang dipilih
                        namaProduk = row.Cells["Nama Product"].Value.ToString();
                        hargaProduk = row.Cells["Harga"].Value.ToString();
                        stokProduk = row.Cells["Stock"].Value.ToString();
                    }
                    
                }

                // Mengisi nilai pada TextBox "produknama" dan "harga"
                namaProduk = NamaDetailsTextBox.Text;
                hargaProduk = HargaTextBox.Text;
                stokProduk = StockTextBox.Text ;
            }
        }
    }
}

﻿namespace HEHE
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.AllButton = new System.Windows.Forms.Button();
            this.FilterButton = new System.Windows.Forms.Button();
            this.ComboBoxFilter = new System.Windows.Forms.ComboBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.ComboBoxCategory = new System.Windows.Forms.ComboBox();
            this.NamaDetailsTextBox = new System.Windows.Forms.TextBox();
            this.HargaTextBox = new System.Windows.Forms.TextBox();
            this.StockTextBox = new System.Windows.Forms.TextBox();
            this.AddProductButton = new System.Windows.Forms.Button();
            this.EditProductButton = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.DatagridviewCategory = new System.Windows.Forms.DataGridView();
            this.label8 = new System.Windows.Forms.Label();
            this.CategoryNamaTextBox = new System.Windows.Forms.TextBox();
            this.AddCategoryButton = new System.Windows.Forms.Button();
            this.RemoveProductButton = new System.Windows.Forms.Button();
            this.RemoveCategoryButton = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DatagridviewCategory)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Sienna;
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox1.Location = new System.Drawing.Point(-2, -16);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(801, 476);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Sienna;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(13, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(86, 25);
            this.label1.TabIndex = 1;
            this.label1.Text = "Product";
            // 
            // AllButton
            // 
            this.AllButton.BackColor = System.Drawing.Color.LightSalmon;
            this.AllButton.Location = new System.Drawing.Point(243, 24);
            this.AllButton.Name = "AllButton";
            this.AllButton.Size = new System.Drawing.Size(36, 24);
            this.AllButton.TabIndex = 2;
            this.AllButton.Text = "All";
            this.AllButton.UseVisualStyleBackColor = false;
            this.AllButton.Click += new System.EventHandler(this.AllButton_Click);
            // 
            // FilterButton
            // 
            this.FilterButton.BackColor = System.Drawing.Color.LightSalmon;
            this.FilterButton.Location = new System.Drawing.Point(298, 24);
            this.FilterButton.Name = "FilterButton";
            this.FilterButton.Size = new System.Drawing.Size(52, 24);
            this.FilterButton.TabIndex = 3;
            this.FilterButton.Text = "Filter";
            this.FilterButton.UseVisualStyleBackColor = false;
            this.FilterButton.Click += new System.EventHandler(this.FilterButton_Click);
            // 
            // ComboBoxFilter
            // 
            this.ComboBoxFilter.BackColor = System.Drawing.Color.LightSalmon;
            this.ComboBoxFilter.Enabled = false;
            this.ComboBoxFilter.FormattingEnabled = true;
            this.ComboBoxFilter.Location = new System.Drawing.Point(366, 24);
            this.ComboBoxFilter.Name = "ComboBoxFilter";
            this.ComboBoxFilter.Size = new System.Drawing.Size(121, 24);
            this.ComboBoxFilter.TabIndex = 4;
            this.ComboBoxFilter.Visible = false;
            this.ComboBoxFilter.SelectedIndexChanged += new System.EventHandler(this.ComboBoxFilter_SelectedIndexChanged);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Cursor = System.Windows.Forms.Cursors.Default;
            this.dataGridView1.GridColor = System.Drawing.Color.MistyRose;
            this.dataGridView1.Location = new System.Drawing.Point(12, 54);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(504, 235);
            this.dataGridView1.TabIndex = 5;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Sienna;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(13, 292);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(78, 25);
            this.label2.TabIndex = 6;
            this.label2.Text = "Details";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Sienna;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(15, 326);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(62, 18);
            this.label3.TabIndex = 7;
            this.label3.Text = "Nama :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Sienna;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(15, 357);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(86, 18);
            this.label4.TabIndex = 8;
            this.label4.Text = "Category :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Sienna;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(15, 389);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(63, 18);
            this.label5.TabIndex = 9;
            this.label5.Text = "Harga :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Sienna;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(15, 417);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(62, 18);
            this.label6.TabIndex = 10;
            this.label6.Text = "Stock :";
            // 
            // ComboBoxCategory
            // 
            this.ComboBoxCategory.BackColor = System.Drawing.Color.LightSalmon;
            this.ComboBoxCategory.FormattingEnabled = true;
            this.ComboBoxCategory.Location = new System.Drawing.Point(126, 351);
            this.ComboBoxCategory.Name = "ComboBoxCategory";
            this.ComboBoxCategory.Size = new System.Drawing.Size(121, 24);
            this.ComboBoxCategory.TabIndex = 11;
            this.ComboBoxCategory.SelectedIndexChanged += new System.EventHandler(this.ComboBoxCategory_SelectedIndexChanged);
            // 
            // NamaDetailsTextBox
            // 
            this.NamaDetailsTextBox.Location = new System.Drawing.Point(126, 321);
            this.NamaDetailsTextBox.Name = "NamaDetailsTextBox";
            this.NamaDetailsTextBox.Size = new System.Drawing.Size(373, 22);
            this.NamaDetailsTextBox.TabIndex = 12;
            // 
            // HargaTextBox
            // 
            this.HargaTextBox.Location = new System.Drawing.Point(126, 385);
            this.HargaTextBox.Name = "HargaTextBox";
            this.HargaTextBox.Size = new System.Drawing.Size(121, 22);
            this.HargaTextBox.TabIndex = 13;
            // 
            // StockTextBox
            // 
            this.StockTextBox.Location = new System.Drawing.Point(126, 416);
            this.StockTextBox.Name = "StockTextBox";
            this.StockTextBox.Size = new System.Drawing.Size(121, 22);
            this.StockTextBox.TabIndex = 14;
            // 
            // AddProductButton
            // 
            this.AddProductButton.BackColor = System.Drawing.Color.NavajoWhite;
            this.AddProductButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.AddProductButton.ForeColor = System.Drawing.Color.IndianRed;
            this.AddProductButton.Location = new System.Drawing.Point(262, 351);
            this.AddProductButton.Name = "AddProductButton";
            this.AddProductButton.Size = new System.Drawing.Size(75, 50);
            this.AddProductButton.TabIndex = 15;
            this.AddProductButton.Text = "Add Product";
            this.AddProductButton.UseVisualStyleBackColor = false;
            this.AddProductButton.Click += new System.EventHandler(this.AddProductButton_Click);
            // 
            // EditProductButton
            // 
            this.EditProductButton.BackColor = System.Drawing.Color.Chartreuse;
            this.EditProductButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.EditProductButton.ForeColor = System.Drawing.Color.ForestGreen;
            this.EditProductButton.Location = new System.Drawing.Point(343, 351);
            this.EditProductButton.Name = "EditProductButton";
            this.EditProductButton.Size = new System.Drawing.Size(75, 50);
            this.EditProductButton.TabIndex = 16;
            this.EditProductButton.Text = "Edit Product";
            this.EditProductButton.UseVisualStyleBackColor = false;
            this.EditProductButton.Click += new System.EventHandler(this.EditProductButton_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Sienna;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(520, 13);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(100, 25);
            this.label7.TabIndex = 18;
            this.label7.Text = "Category";
            // 
            // DatagridviewCategory
            // 
            this.DatagridviewCategory.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DatagridviewCategory.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.DatagridviewCategory.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DatagridviewCategory.GridColor = System.Drawing.Color.MistyRose;
            this.DatagridviewCategory.Location = new System.Drawing.Point(526, 41);
            this.DatagridviewCategory.Name = "DatagridviewCategory";
            this.DatagridviewCategory.RowHeadersVisible = false;
            this.DatagridviewCategory.RowHeadersWidth = 51;
            this.DatagridviewCategory.RowTemplate.Height = 24;
            this.DatagridviewCategory.Size = new System.Drawing.Size(253, 180);
            this.DatagridviewCategory.TabIndex = 19;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Sienna;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(522, 224);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(62, 18);
            this.label8.TabIndex = 20;
            this.label8.Text = "Nama :";
            // 
            // CategoryNamaTextBox
            // 
            this.CategoryNamaTextBox.Location = new System.Drawing.Point(590, 224);
            this.CategoryNamaTextBox.Name = "CategoryNamaTextBox";
            this.CategoryNamaTextBox.Size = new System.Drawing.Size(189, 22);
            this.CategoryNamaTextBox.TabIndex = 21;
            // 
            // AddCategoryButton
            // 
            this.AddCategoryButton.BackColor = System.Drawing.Color.NavajoWhite;
            this.AddCategoryButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.AddCategoryButton.ForeColor = System.Drawing.Color.IndianRed;
            this.AddCategoryButton.Location = new System.Drawing.Point(590, 252);
            this.AddCategoryButton.Name = "AddCategoryButton";
            this.AddCategoryButton.Size = new System.Drawing.Size(81, 50);
            this.AddCategoryButton.TabIndex = 22;
            this.AddCategoryButton.Text = "Add Category";
            this.AddCategoryButton.UseVisualStyleBackColor = false;
            this.AddCategoryButton.Click += new System.EventHandler(this.AddCategoryButton_Click);
            // 
            // RemoveProductButton
            // 
            this.RemoveProductButton.BackColor = System.Drawing.Color.Red;
            this.RemoveProductButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.RemoveProductButton.ForeColor = System.Drawing.Color.Snow;
            this.RemoveProductButton.Location = new System.Drawing.Point(424, 351);
            this.RemoveProductButton.Name = "RemoveProductButton";
            this.RemoveProductButton.Size = new System.Drawing.Size(75, 50);
            this.RemoveProductButton.TabIndex = 17;
            this.RemoveProductButton.Text = "Remove Product";
            this.RemoveProductButton.UseVisualStyleBackColor = false;
            this.RemoveProductButton.Click += new System.EventHandler(this.RemoveProductButton_Click);
            // 
            // RemoveCategoryButton
            // 
            this.RemoveCategoryButton.BackColor = System.Drawing.Color.Red;
            this.RemoveCategoryButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.RemoveCategoryButton.ForeColor = System.Drawing.Color.Snow;
            this.RemoveCategoryButton.Location = new System.Drawing.Point(699, 252);
            this.RemoveCategoryButton.Name = "RemoveCategoryButton";
            this.RemoveCategoryButton.Size = new System.Drawing.Size(80, 50);
            this.RemoveCategoryButton.TabIndex = 23;
            this.RemoveCategoryButton.Text = "Remove Category";
            this.RemoveCategoryButton.UseVisualStyleBackColor = false;
            this.RemoveCategoryButton.Click += new System.EventHandler(this.RemoveCategoryButton_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.BackgroundImage")));
            this.pictureBox2.ErrorImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.ErrorImage")));
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.InitialImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.InitialImage")));
            this.pictureBox2.Location = new System.Drawing.Point(526, 308);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(253, 130);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 24;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.RemoveCategoryButton);
            this.Controls.Add(this.AddCategoryButton);
            this.Controls.Add(this.CategoryNamaTextBox);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.DatagridviewCategory);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.RemoveProductButton);
            this.Controls.Add(this.EditProductButton);
            this.Controls.Add(this.AddProductButton);
            this.Controls.Add(this.StockTextBox);
            this.Controls.Add(this.HargaTextBox);
            this.Controls.Add(this.NamaDetailsTextBox);
            this.Controls.Add(this.ComboBoxCategory);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.ComboBoxFilter);
            this.Controls.Add(this.FilterButton);
            this.Controls.Add(this.AllButton);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DatagridviewCategory)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button AllButton;
        private System.Windows.Forms.Button FilterButton;
        private System.Windows.Forms.ComboBox ComboBoxFilter;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox ComboBoxCategory;
        private System.Windows.Forms.TextBox NamaDetailsTextBox;
        private System.Windows.Forms.TextBox HargaTextBox;
        private System.Windows.Forms.TextBox StockTextBox;
        private System.Windows.Forms.Button AddProductButton;
        private System.Windows.Forms.Button EditProductButton;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.DataGridView DatagridviewCategory;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox CategoryNamaTextBox;
        private System.Windows.Forms.Button AddCategoryButton;
        private System.Windows.Forms.Button RemoveProductButton;
        private System.Windows.Forms.Button RemoveCategoryButton;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}


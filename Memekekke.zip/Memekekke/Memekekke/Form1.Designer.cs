﻿namespace Memekekke
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.playertextbox = new System.Windows.Forms.TextBox();
            this.teamnumbertextbox = new System.Windows.Forms.TextBox();
            this.positiontextbox = new System.Windows.Forms.TextBox();
            this.heighttextBox = new System.Windows.Forms.TextBox();
            this.weighttextBox = new System.Windows.Forms.TextBox();
            this.teamnamecombobox = new System.Windows.Forms.ComboBox();
            this.paneljembot = new System.Windows.Forms.Panel();
            this.dataGridViewlistplayer = new System.Windows.Forms.DataGridView();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.buttonSubmit = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.addPlayerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editManagerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deletePlayerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panel2 = new System.Windows.Forms.Panel();
            this.updatebutton = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label12 = new System.Windows.Forms.Label();
            this.ComboBoxNationality = new System.Windows.Forms.ComboBox();
            this.datatempik = new System.Windows.Forms.DataGridView();
            this.comboboxpanel1 = new System.Windows.Forms.ComboBox();
            this.Delete = new System.Windows.Forms.Button();
            this.paneljembot.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewlistplayer)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.datatempik)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(16, 11);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(74, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Add Player";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(16, 44);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(86, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Player Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(16, 78);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(94, 16);
            this.label3.TabIndex = 2;
            this.label3.Text = "Team Number";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(16, 112);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(55, 16);
            this.label4.TabIndex = 3;
            this.label4.Text = "Position";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(16, 144);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(46, 16);
            this.label5.TabIndex = 4;
            this.label5.Text = "Height";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(17, 176);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(49, 16);
            this.label6.TabIndex = 5;
            this.label6.Text = "Weight";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(16, 212);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(60, 16);
            this.label7.TabIndex = 6;
            this.label7.Text = "Birthdate";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(16, 274);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(83, 16);
            this.label8.TabIndex = 7;
            this.label8.Text = "Team Name";
            // 
            // playertextbox
            // 
            this.playertextbox.Location = new System.Drawing.Point(127, 34);
            this.playertextbox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.playertextbox.Name = "playertextbox";
            this.playertextbox.Size = new System.Drawing.Size(132, 22);
            this.playertextbox.TabIndex = 8;
            // 
            // teamnumbertextbox
            // 
            this.teamnumbertextbox.Location = new System.Drawing.Point(127, 74);
            this.teamnumbertextbox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.teamnumbertextbox.Name = "teamnumbertextbox";
            this.teamnumbertextbox.Size = new System.Drawing.Size(67, 22);
            this.teamnumbertextbox.TabIndex = 9;
            // 
            // positiontextbox
            // 
            this.positiontextbox.Location = new System.Drawing.Point(127, 108);
            this.positiontextbox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.positiontextbox.Name = "positiontextbox";
            this.positiontextbox.Size = new System.Drawing.Size(67, 22);
            this.positiontextbox.TabIndex = 10;
            // 
            // heighttextBox
            // 
            this.heighttextBox.Location = new System.Drawing.Point(127, 140);
            this.heighttextBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.heighttextBox.Name = "heighttextBox";
            this.heighttextBox.Size = new System.Drawing.Size(67, 22);
            this.heighttextBox.TabIndex = 11;
            // 
            // weighttextBox
            // 
            this.weighttextBox.Location = new System.Drawing.Point(127, 172);
            this.weighttextBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.weighttextBox.Name = "weighttextBox";
            this.weighttextBox.Size = new System.Drawing.Size(67, 22);
            this.weighttextBox.TabIndex = 12;
            // 
            // teamnamecombobox
            // 
            this.teamnamecombobox.FormattingEnabled = true;
            this.teamnamecombobox.Location = new System.Drawing.Point(127, 274);
            this.teamnamecombobox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.teamnamecombobox.Name = "teamnamecombobox";
            this.teamnamecombobox.Size = new System.Drawing.Size(160, 24);
            this.teamnamecombobox.TabIndex = 14;
            this.teamnamecombobox.SelectedIndexChanged += new System.EventHandler(this.teamnamecombobox_SelectedIndexChanged);
            // 
            // paneljembot
            // 
            this.paneljembot.Controls.Add(this.ComboBoxNationality);
            this.paneljembot.Controls.Add(this.label12);
            this.paneljembot.Controls.Add(this.dataGridViewlistplayer);
            this.paneljembot.Controls.Add(this.dateTimePicker1);
            this.paneljembot.Controls.Add(this.buttonSubmit);
            this.paneljembot.Controls.Add(this.label1);
            this.paneljembot.Controls.Add(this.teamnamecombobox);
            this.paneljembot.Controls.Add(this.label2);
            this.paneljembot.Controls.Add(this.label3);
            this.paneljembot.Controls.Add(this.weighttextBox);
            this.paneljembot.Controls.Add(this.label4);
            this.paneljembot.Controls.Add(this.heighttextBox);
            this.paneljembot.Controls.Add(this.label5);
            this.paneljembot.Controls.Add(this.positiontextbox);
            this.paneljembot.Controls.Add(this.label6);
            this.paneljembot.Controls.Add(this.teamnumbertextbox);
            this.paneljembot.Controls.Add(this.label7);
            this.paneljembot.Controls.Add(this.playertextbox);
            this.paneljembot.Controls.Add(this.label8);
            this.paneljembot.Location = new System.Drawing.Point(16, 33);
            this.paneljembot.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.paneljembot.Name = "paneljembot";
            this.paneljembot.Size = new System.Drawing.Size(892, 335);
            this.paneljembot.TabIndex = 15;
            this.paneljembot.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // dataGridViewlistplayer
            // 
            this.dataGridViewlistplayer.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dataGridViewlistplayer.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.dataGridViewlistplayer.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewlistplayer.Location = new System.Drawing.Point(413, 12);
            this.dataGridViewlistplayer.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dataGridViewlistplayer.Name = "dataGridViewlistplayer";
            this.dataGridViewlistplayer.RowHeadersWidth = 51;
            this.dataGridViewlistplayer.Size = new System.Drawing.Size(475, 323);
            this.dataGridViewlistplayer.TabIndex = 17;
            this.dataGridViewlistplayer.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewlistplayer_CellContentClick);
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(127, 212);
            this.dateTimePicker1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(265, 22);
            this.dateTimePicker1.TabIndex = 16;
            // 
            // buttonSubmit
            // 
            this.buttonSubmit.Location = new System.Drawing.Point(160, 303);
            this.buttonSubmit.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.buttonSubmit.Name = "buttonSubmit";
            this.buttonSubmit.Size = new System.Drawing.Size(100, 28);
            this.buttonSubmit.TabIndex = 15;
            this.buttonSubmit.Text = "Submit";
            this.buttonSubmit.UseVisualStyleBackColor = true;
            this.buttonSubmit.Click += new System.EventHandler(this.buttonSubmit_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addPlayerToolStripMenuItem,
            this.editManagerToolStripMenuItem,
            this.deletePlayerToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1623, 28);
            this.menuStrip1.TabIndex = 16;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // addPlayerToolStripMenuItem
            // 
            this.addPlayerToolStripMenuItem.Name = "addPlayerToolStripMenuItem";
            this.addPlayerToolStripMenuItem.Size = new System.Drawing.Size(95, 24);
            this.addPlayerToolStripMenuItem.Text = "Add Player";
            this.addPlayerToolStripMenuItem.Click += new System.EventHandler(this.addPlayerToolStripMenuItem_Click);
            // 
            // editManagerToolStripMenuItem
            // 
            this.editManagerToolStripMenuItem.Name = "editManagerToolStripMenuItem";
            this.editManagerToolStripMenuItem.Size = new System.Drawing.Size(112, 24);
            this.editManagerToolStripMenuItem.Text = "Edit Manager";
            this.editManagerToolStripMenuItem.Click += new System.EventHandler(this.editManagerToolStripMenuItem_Click);
            // 
            // deletePlayerToolStripMenuItem
            // 
            this.deletePlayerToolStripMenuItem.Name = "deletePlayerToolStripMenuItem";
            this.deletePlayerToolStripMenuItem.Size = new System.Drawing.Size(111, 24);
            this.deletePlayerToolStripMenuItem.Text = "Delete Player";
            this.deletePlayerToolStripMenuItem.Click += new System.EventHandler(this.deletePlayerToolStripMenuItem_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.updatebutton);
            this.panel2.Controls.Add(this.label11);
            this.panel2.Controls.Add(this.dataGridView2);
            this.panel2.Controls.Add(this.dataGridView1);
            this.panel2.Controls.Add(this.label10);
            this.panel2.Controls.Add(this.label9);
            this.panel2.Controls.Add(this.comboBox1);
            this.panel2.Location = new System.Drawing.Point(916, 33);
            this.panel2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(761, 352);
            this.panel2.TabIndex = 17;
            // 
            // updatebutton
            // 
            this.updatebutton.Location = new System.Drawing.Point(437, 292);
            this.updatebutton.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.updatebutton.Name = "updatebutton";
            this.updatebutton.Size = new System.Drawing.Size(100, 28);
            this.updatebutton.TabIndex = 18;
            this.updatebutton.Text = "update";
            this.updatebutton.UseVisualStyleBackColor = true;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(15, 169);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(133, 16);
            this.label11.TabIndex = 19;
            this.label11.Text = "Available to recruited";
            // 
            // dataGridView2
            // 
            this.dataGridView2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dataGridView2.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(19, 188);
            this.dataGridView2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowHeadersWidth = 51;
            this.dataGridView2.Size = new System.Drawing.Size(411, 143);
            this.dataGridView2.TabIndex = 18;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dataGridView1.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(19, 66);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.Size = new System.Drawing.Size(411, 86);
            this.dataGridView1.TabIndex = 17;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(15, 38);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(83, 16);
            this.label10.TabIndex = 16;
            this.label10.Text = "Team Name";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(15, 11);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(87, 16);
            this.label9.TabIndex = 16;
            this.label9.Text = "Edit Manager";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(109, 33);
            this.comboBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(160, 24);
            this.comboBox1.TabIndex = 16;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.Delete);
            this.panel1.Controls.Add(this.comboboxpanel1);
            this.panel1.Controls.Add(this.datatempik);
            this.panel1.Location = new System.Drawing.Point(17, 401);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(887, 335);
            this.panel1.TabIndex = 18;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(17, 245);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(70, 16);
            this.label12.TabIndex = 18;
            this.label12.Text = "Nationality";
            this.label12.Click += new System.EventHandler(this.label12_Click);
            // 
            // ComboBoxNationality
            // 
            this.ComboBoxNationality.FormattingEnabled = true;
            this.ComboBoxNationality.Location = new System.Drawing.Point(127, 244);
            this.ComboBoxNationality.Name = "ComboBoxNationality";
            this.ComboBoxNationality.Size = new System.Drawing.Size(121, 24);
            this.ComboBoxNationality.TabIndex = 19;
            // 
            // datatempik
            // 
            this.datatempik.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.datatempik.Location = new System.Drawing.Point(412, 14);
            this.datatempik.Name = "datatempik";
            this.datatempik.RowHeadersWidth = 51;
            this.datatempik.RowTemplate.Height = 24;
            this.datatempik.Size = new System.Drawing.Size(461, 308);
            this.datatempik.TabIndex = 0;
            // 
            // comboboxpanel1
            // 
            this.comboboxpanel1.FormattingEnabled = true;
            this.comboboxpanel1.Location = new System.Drawing.Point(18, 14);
            this.comboboxpanel1.Name = "comboboxpanel1";
            this.comboboxpanel1.Size = new System.Drawing.Size(229, 24);
            this.comboboxpanel1.TabIndex = 1;
            // 
            // Delete
            // 
            this.Delete.Location = new System.Drawing.Point(316, 15);
            this.Delete.Name = "Delete";
            this.Delete.Size = new System.Drawing.Size(75, 23);
            this.Delete.TabIndex = 2;
            this.Delete.Text = "Delete";
            this.Delete.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1623, 804);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.paneljembot);
            this.Controls.Add(this.menuStrip1);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.paneljembot.ResumeLayout(false);
            this.paneljembot.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewlistplayer)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.datatempik)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox playertextbox;
        private System.Windows.Forms.TextBox teamnumbertextbox;
        private System.Windows.Forms.TextBox positiontextbox;
        private System.Windows.Forms.TextBox heighttextBox;
        private System.Windows.Forms.TextBox weighttextBox;
        private System.Windows.Forms.ComboBox teamnamecombobox;
        private System.Windows.Forms.Panel paneljembot;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Button buttonSubmit;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem addPlayerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem editManagerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem deletePlayerToolStripMenuItem;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.DataGridView dataGridViewlistplayer;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.Button updatebutton;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ComboBox ComboBoxNationality;
        private System.Windows.Forms.DataGridView datatempik;
        private System.Windows.Forms.ComboBox comboboxpanel1;
        private System.Windows.Forms.Button Delete;
    }
}

